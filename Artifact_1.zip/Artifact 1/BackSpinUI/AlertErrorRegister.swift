//
//  AlertErrorRegister.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

//
//  AlertError.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

import Foundation
import SwiftUI

struct AlertErrorRegister: View {
    @Binding var showingAlertRegister:Bool

    var body: some View {
        VStack{
            
            
       
    }     .alert(NSLocalizedString("Error!", comment: ""), isPresented: $showingAlertRegister, actions: {
        Button("Ok", action: {showingAlertRegister = false })
        }, message: {
          Text("User already exists.")
        })        }

}
