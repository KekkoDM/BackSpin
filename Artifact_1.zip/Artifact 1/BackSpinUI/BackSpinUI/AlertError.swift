//
//  AlertError.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

import Foundation
import SwiftUI

struct AlertErrorLogin: View {
    @Binding var showingAlert:Bool

    var body: some View {
        VStack{
            
            
       
    }     .alert(NSLocalizedString("Error!", comment: ""), isPresented: $showingAlert, actions: {
        Button("Ok", action: {showingAlert = false })
        }, message: {
          Text("Please enter correct credential.")
        })        }

}
