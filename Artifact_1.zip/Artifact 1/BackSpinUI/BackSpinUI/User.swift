//
//  User.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

import Foundation

public struct User: Decodable{
    var id: UUID?
    var username:String
    var password:String
}
