//
//  LoginView.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

import Foundation
import SwiftUI



struct LoginView: View {
    @Binding var user : User
    @State var password = ""
    @State var showingAlertField: Bool = false
    @State var contentView: Bool = false
    
    var body: some View {
        
        NavigationView{
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(Color.white)
                    .frame(width: 1000, height: 1000, alignment: .center)
                
                VStack () {
                    HStack {
                        
                        NavigationLink("Back",destination: ContentView())
                            .padding(.leading,-50)
                        Text ("Change Password")
                            .foregroundColor(.black)
                            .font(.title)
                            .padding(.trailing)
                    }
                    .padding(.bottom,290)
                    HStack {
                        Text("Username: ")
                            .foregroundColor(.blue)
                        Text(user.username)
                            .foregroundColor(.black)
                    }.padding(.bottom, 8)
                    
                    HStack {
                        Text("Password: ")
                            .foregroundColor(.blue)
                        Text(user.password)
                            .foregroundColor(.black)
                    }.padding(.bottom, 16)
                    
                    SecureField("New password",text: $password)
                        .foregroundColor(.black)
                        .padding()
                        .frame(width: 300, height: 35, alignment: .center)
                        .padding(12)
                        .overlay (
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(Color.blue, lineWidth: 1)
                                .frame(width: 300, height: 35, alignment: .center)
                        )
                        .padding(.bottom, 250)
                    
                    Button(action: {
                        if password == "" {
                            self.showingAlertField = true
                        } else {
                            update()
                            user.password = password
                        }
                        
                    }) {
                        ZStack{
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundColor(Color.blue)
                                .frame(width: 300, height: 50, alignment: .center)
                            Text( "Update")
                                .foregroundColor(Color.white)
                        }
                    }.padding(.bottom, 10)
                    
                }
                Spacer()
                if showingAlertField == true {
                    AlertErrorField(showingAlertField: $showingAlertField)
                }
                
                
                
            }.navigationBarHidden(true)
        }
        
        
    }
    
    
    
    func updateBello(){
        let request = NSMutableURLRequest(url: NSURL(string:
                                                        "http://127.0.0.1:8080/update")! as URL)
        request.httpMethod = "PUT"
        let postUser = "username=\(user.username)"
        let postPassword = "password=\(password)"
        
        let postString = postUser + "&" + postPassword
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type") //Optional
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=(String(describing: error))")
                return
            }
            
            if let data = data {
                let jsonDecoder = JSONDecoder()
                do {
                    let parsedJSON = try jsonDecoder.decode(User.self, from: data)
                    print(parsedJSON)
                    
                    
                } catch {
                    print(error)
                }
            }
        }
        task.resume()
    }
    
    
    
    func update(){
        print("USER: " + user.username)
        let request = NSMutableURLRequest(url: NSURL(string:
                                                        "http://127.0.0.1:8080/update/\(user.username)/\(password)")! as URL)
        request.httpMethod = "PUT"
        let postUser = "username=\(user.username)"
        let postPassword = "password=\(password)"
        
        print(postUser)
        
        print(postPassword)
        
        let postString = postUser + "&" + postPassword
        print(postString)
        
        request.httpBody = postString.data(using: String.Encoding.utf8)
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                
                
                print("error=(String(describing: error))")
                
                return
            }
            
            
            
            if let data = data {
                let jsonDecoder = JSONDecoder()
                do {
                    let parsedJSON = try jsonDecoder.decode(User.self, from: data)
                    print(parsedJSON)
                    
                    
                } catch {
                    print(error)
                }
            }
        }
        task.resume()
    }
    
    
}
