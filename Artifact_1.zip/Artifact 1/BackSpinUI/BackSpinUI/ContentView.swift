//
//  ContentView.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//
import Foundation

import SwiftUI



struct ContentView: View {
    @State var altezza:CGFloat = 40
    @State var larghezza:CGFloat = 150
    @State var username = ""
    @State var password = ""
    @State var showingAlert:Bool = false
    @State var showingAlertRegister:Bool = false
    
    
    @State var loginView:Bool = false
    @State var user : User = User(id: nil, username: "", password: "")
    
    var body: some View {
        
        ZStack {
            
            VStack {
                Text("BACKSPIN")
                    .foregroundColor(.black)
                    .font(.title)
                    .padding(.top, 30)
                
                Spacer()
                
                TextField("Username", text: $username)
                    .padding(.horizontal)
                
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(.black)
                    .frame(width: 300, height: 0.5, alignment: .leading)
                    .padding(.trailing, 80)
                
                SecureField("Password", text: $password)
                    .padding(.horizontal)
                
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(.black)
                    .frame(width: 300, height: 0.5, alignment: .leading)
                    .padding(.trailing, 80)
                
                Spacer()
                
                HStack (spacing: 15){
                    Button (action: {
                        loginUser()
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundColor(.blue)
                                .frame(width: larghezza, height: altezza, alignment: .center)
                            Text("Login")
                                .foregroundColor(.white)
                        }
                    }.padding(.bottom, 40)
                    
                    Button (action: {
                        registra()
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundColor(.blue)
                                .frame(width: larghezza, height: altezza, alignment: .center)
                            Text("Sing Up")
                                .foregroundColor(.white)
                        }
                    }.padding(.bottom, 40)
                }
            }
            
            if showingAlert == true {
                AlertErrorLogin(showingAlert: $showingAlert)
            }
            
            if showingAlertRegister == true {
                AlertErrorRegister(showingAlertRegister: $showingAlertRegister)
            }
            
            if (loginView == true) {
                LoginView(user:$user)
            }
        }.navigationBarHidden(true)
        
    }
    public func loginUser(){
        
        //        print("USER: " + user[0].username)
        let request = NSMutableURLRequest(url: NSURL(string:
                                                        "http://127.0.0.1:8080/login")! as URL)
        request.httpMethod = "POST"
        let postUser = "username=" + username
        let postPassword = "password=" + password
        let postString = postUser + "&" + postPassword
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                print("error=(String(describing: error))")
                
                return
                
            }
            
            
            
            
            if let data = data {
                let jsonDecoder = JSONDecoder()
                do {
                    let parsedJSON = try jsonDecoder.decode([User].self, from: data)
                    print(parsedJSON)
                    
                    
                    
                    user = parsedJSON.first ?? user
                    print(user)
                    
                    if user.id != nil {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            loginView = true
                            
                        }
                    }else{
                        self.showingAlert = true
                        print(showingAlert)
                    }
                    print(user)
                } catch {
                    print(error)
                }
            }
        }
        task.resume()
    }
    
    
    
    func registra(){
        
        //        print("USER: " + user[0].username)
        let request = NSMutableURLRequest(url: NSURL(string:
                                                        "http://127.0.0.1:8080/registra")! as URL)
        request.httpMethod = "POST"
        let postUser = "username=" + username
        let postPassword = "password=" + password
        let postString = postUser + "&" + postPassword
        request.httpBody = postString.data(using: String.Encoding.utf8)
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                
                print("error=(String(describing: error))")
                
                return
            }
            
            
            
            
            
            if let data = data {
                let jsonDecoder = JSONDecoder()
                
                do {
                    let parsedJSON = try jsonDecoder.decode(User.self, from: data)
                    print(parsedJSON)
                } catch {
                    print(error)
                }
            }
        }
        task.resume()
    }
    
    
    
}
