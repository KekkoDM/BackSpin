//
//  BackSpinUIApp.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

import SwiftUI

@main

struct BackSpinUIApp: App {


    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
