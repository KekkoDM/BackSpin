//
//  AlertErrorField.swift
//  BackSpinUI
//
//  Created by Simona Ettari on 24/03/22.
//

import SwiftUI

struct AlertErrorField: View {
    @Binding var showingAlertField: Bool
    
    var body: some View {
        VStack{
            
        }.alert(NSLocalizedString("Error!", comment: ""), isPresented: $showingAlertField, actions: {
            Button("Ok", action: {showingAlertField = false })
        }, message: {
            Text("Please complete all fields.")
        })
    }
}
