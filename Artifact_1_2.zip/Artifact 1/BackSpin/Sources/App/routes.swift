import Fluent
import Vapor
struct UserStruct:Content{
    var username:String
    var password:String

}
func routes(_ app: Application) throws {
    app.get { req in
        return req.view.render("index", ["title": "Hello Vapor!"])
    }

    app.get("prendi") { req  -> EventLoopFuture<[Todo]>  in
        return Todo.query(on: req.db).all()
    }
    app.get(":username",":password") { req -> String in
        guard let username = req.parameters.get("username",as: String.self) else {throw Abort(.badRequest)}
        guard let password = req.parameters.get("password",as: String.self) else {throw Abort(.badRequest)}

        return username + " " + password
    }
    app.post("registra"){req  -> EventLoopFuture<Todo> in
        let data = try req.content.decode(Todo.self)
        let user = Todo(username: data.username, password: data.password)
        return user.save(on: req.db).map{user}
         
    }
    app.post("login"){req  -> EventLoopFuture<[Todo]> in
        let data = try req.content.decode(Todo.self)
        return Todo.query(on: req.db).filter(\.$username == data.username).filter(\.$password == data.password).all()
    }
    
    app.put("update"){req  -> EventLoopFuture<Todo> in
        let data = try req.content.decode(Todo.self)
        let user = Todo(username: data.username, password: data.password)
         
        return Todo.query(on: req.db)
            .set(\.$password, to: data.password)
            .filter(\.$username == data.username)
            .update().map{user}

//        Todo.query(on: req.db)
//            .filter(\.$username == data.username)
//            .all()
            
    }
    
    
    app.put("update", ":username", ":password"){ req -> String in

                guard let oldUsername = req.parameters.get("username", as: String.self) else {
                    throw Abort(.badRequest)
                }

                guard let newPassword = req.parameters.get("password", as: String.self) else {
                    throw Abort(.badRequest)
                }

                Todo.query(on: req.db)
                            .set(\.$password, to: newPassword)
                            .filter(\.$username == oldUsername).update()

                return ""
            }
    try app.register(collection: TodoController())
}

