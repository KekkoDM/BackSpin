import Fluent
import Vapor

final class Todo: Model, Content {

    
    static let schema = "User"
    @ID(key: .id)
    var id: UUID?
    @Field(key: "username")
    var username: String

    @Field(key: "password")
    var password: String

    init() { }

    init(username: String, password: String) {
        self.username = username
        self.password = password
    }
    
    init(id: UUID, username: String, password: String){
        self.id = id
        self.username = username
        self.password = password
    }
}
