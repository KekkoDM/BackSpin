//
//  User.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//

import Foundation

public struct User: Encodable, Decodable{
    var id: UUID?
    var username:String
    var password:String
    
    init(id: UUID?, username: String, password:String){
        self.id = id
        self.username = username
        self.password = password

    }
    
    init(_ data: Data, _ :Bool) throws{
        let jsonDecoder = JSONDecoder()
        let tmpUser = try jsonDecoder.decode([User].self, from: data)
        print(tmpUser)
        self.id = tmpUser.first?.id
        self.username = tmpUser.first!.username
        self.password = tmpUser.first!.password

        print("PROVA: " ,self)
    }
    
    init(_ data: Data) throws{
        let jsonDecoder = JSONDecoder()
        let user = try jsonDecoder.decode(User.self, from: data)
        self.id = user.id
        self.username = user.username
        self.password = user.password
        print(self)
    }
    public func loginUser() async -> User?{
        
        let request = NSMutableURLRequest(url: NSURL(string:
                                                        "http://127.0.0.1:8080/login")! as URL)
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type") // the request is JSON
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        
        request.httpMethod = "POST"
        
        guard let jsonData = try? JSONEncoder().encode(self) else {
            print("Error: Trying to convert model to JSON data")
            return nil
        }
        request.httpBody = jsonData
        
        do{
            let(data, response) = try await URLSession.shared.data(for: request as URLRequest)
            
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else{
                      return nil
                  }
            
            let tmpUser = try User(data, true)
            
            return tmpUser
        }catch{
            print("Error fetching the user")
            return nil
        }
        
    }
    
    
    
    func registra() async -> User? {
        
        //        print("USER: " + user[0].username)
        let request = NSMutableURLRequest(url: NSURL(string:
                                                        "http://127.0.0.1:8080/registra")! as URL)
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type") // the request is JSON
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpMethod = "POST"
        guard let jsonData = try? JSONEncoder().encode(self) else {
            print("Error: Trying to convert model to JSON data")
            return nil
        }
        request.httpBody = jsonData
        
        do{
            let(data, response) = try await URLSession.shared.data(for: request as URLRequest)
            
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else{
                      return nil
                  }
            
            let tmpUser = try User(data, true)
            
            return tmpUser
        }catch{
            print("Error fetching the user")
            return nil
        }
    }
}
