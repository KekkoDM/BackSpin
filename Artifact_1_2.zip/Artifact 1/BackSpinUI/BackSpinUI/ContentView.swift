//
//  ContentView.swift
//  BackSpinUI
//
//  Created by Nicola D'Abrosca on 24/03/22.
//
import Foundation

import SwiftUI



struct ContentView: View {
    @State var altezza:CGFloat = 40
    @State var larghezza:CGFloat = 150
    //    @State var username = ""
    //    @State var password = ""
    @State var showingAlert:Bool = false
    @State var showingAlertRegister:Bool = false
    
    
    @State var loginView:Bool = false
    @State var user : User = User(id: nil, username: "", password: "")
    
    var body: some View {
        
        ZStack {
            
            VStack {
                Text("BACKSPIN")
                    .foregroundColor(.black)
                    .font(.title)
                    .padding(.top, 30)
                
                Spacer()
                
                TextField("Username", text: $user.username)
                    .padding(.horizontal)
                
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(.black)
                    .frame(width: 300, height: 0.5, alignment: .leading)
                    .padding(.trailing, 80)
                
                SecureField("Password", text: $user.password)
                    .padding(.horizontal)
                
                RoundedRectangle(cornerRadius: 25)
                    .foregroundColor(.black)
                    .frame(width: 300, height: 0.5, alignment: .leading)
                    .padding(.trailing, 80)
                
                Spacer()
                
                HStack (spacing: 15){
                    Button (action: {
                        Task{
                            await user.loginUser()
                            loginView = true
                        }
                        
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundColor(.blue)
                                .frame(width: larghezza, height: altezza, alignment: .center)
                            Text("Login")
                                .foregroundColor(.white)
                        }
                    }.padding(.bottom, 40)
                    
                    Button (action: {
                        Task{    await user.registra()}
                    }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25)
                                .foregroundColor(.blue)
                                .frame(width: larghezza, height: altezza, alignment: .center)
                            Text("Sing Up")
                                .foregroundColor(.white)
                        }
                    }.padding(.bottom, 40)
                }
            }
            
            if showingAlert == true {
                AlertErrorLogin(showingAlert: $showingAlert)
            }
            
            if showingAlertRegister == true {
                AlertErrorRegister(showingAlertRegister: $showingAlertRegister)
            }
            
            if (loginView == true) {
                LoginView(user:$user)
            }
        }.navigationBarHidden(true)
        
    }
   
}
